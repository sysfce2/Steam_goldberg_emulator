#pragma once

#include <stdint.h>
// ImTextureID [configurable type: override in imconfig.h with '#define ImTextureID xxx']
#define ImTextureID uint64_t